# PHP VPN client for macOS

No distributable client implementation is available for this platform yet.
This directory does not claim platform support or completed validation.
